import  {createAuth0Client, Auth0Client, LogoutOptions, GetTokenSilentlyOptions, GetTokenWithPopupOptions, RedirectLoginOptions, User } from '@auth0/auth0-spa-js'
// import createAuth0Client, { Auth0Client, Auth0ClientOptions, GetIdTokenClaimsOptions, LogoutOptions, RedirectLoginOptions, User } from '@auth0/auth0-spa-js'
import { App, computed, reactive, watchEffect } from 'vue'
import { NavigationGuardNext, RouteLocationNormalized } from 'vue-router'

let client: Auth0Client

const state = reactive({
  loading: true,
  isAuthenticated: false,
  user: {} as User | undefined,
  popupOpen: false,
  error: null as any
})

async function loginWithPopup () {
  state.popupOpen = true

  try {
    await client.loginWithPopup()
  } catch (e) {
    console.error(e)
  } finally {
    state.popupOpen = false
  }

  state.user = await client.getUser()
  state.isAuthenticated = true
}

async function handleRedirectCallback () {
  state.loading = true

  try {
    console.log('call handleRedirectCallback')
    await client.handleRedirectCallback()
    state.user = await client.getUser()
    state.isAuthenticated = true
  } catch (e:any) {
    state.error = e
  } finally {
    state.loading = false
  }
}

function loginWithRedirect (o: RedirectLoginOptions | undefined) {
  return client.loginWithRedirect(o)
}

// function getIdTokenClaims (o: GetIdTokenClaimsOptions | undefined) {
//   return client.getIdTokenClaims(o)
// }

// function getTokenSilently (o: GetIdTokenClaimsOptions | undefined) {
//   return client.getTokenSilently(o)
// }

// function getTokenWithPopup (o: GetIdTokenClaimsOptions | undefined) {
//   return client.getTokenWithPopup(o)
// }
function getIdTokenClaims () {
  return client.getIdTokenClaims()
}

function getTokenSilently (o: GetTokenSilentlyOptions | undefined) {
  return client.getTokenSilently(o)
}

function getTokenWithPopup (o:GetTokenWithPopupOptions | undefined) {
  return client.getTokenWithPopup(o)
}

function logout (o: LogoutOptions | undefined) {
  window.localStorage.removeItem('xxx-system')
  return client.logout(o)
}

const authPlugin = {
  isAuthenticated: computed(() => state.isAuthenticated),
  loading: computed(() => state.loading),
  user: computed(() => state.user),
  getIdTokenClaims,
  getTokenSilently,
  getTokenWithPopup,
  handleRedirectCallback,
  loginWithRedirect,
  loginWithPopup,
  logout
}

export const routeGuard = (to: RouteLocationNormalized, from: RouteLocationNormalized, next: NavigationGuardNext) => {
  const { isAuthenticated, loading, loginWithRedirect } = authPlugin

  const verify = () => {
    if (isAuthenticated.value) {
      return next()
    }

    loginWithRedirect({ appState: { targetUrl: to.fullPath } })
  }

  if (!loading.value) {
    return verify()
  }

  watchEffect(() => {
    if (loading.value === false) {
      return verify()
    }
  })
}

export const setupAuth = async (callbackRedirect) => {
  client = await createAuth0Client({
    domain:(import.meta.env.VITE_APP_AUTH_DOMAIN),
    clientId:(import.meta.env.VITE_APP_AUTH_CLIENT_ID),
    authorizationParams: {
      redirect_uri: (import.meta.env.VITE_APP_AUTH_REDIRECT_URL)
    }
  })

// export const setupAuth = async (callbackRedirect) => {
//   client = await createAuth0Client({
//     domain:(import.meta.env.VITE_APP_AUTH_DOMAIN),
//     client_id:(import.meta.env.VITE_APP_AUTH_CLIENT_ID),
//     redirect_uri: (import.meta.env.VITE_APP_AUTH_REDIRECT_URL)
//   })

  try {
    console.log('setupAuth Start')
    if (
      window.location.search.includes('code=') &&
      window.location.search.includes('state=')
    ) {
      const { appState } = await client.handleRedirectCallback()
      callbackRedirect(appState)
      console.log('call callbackRedirect')
      window.history.replaceState({},document.title,"/")
    }
  } catch (e:any) {
    state.error = e
  } finally {
    // Initialize our internal authentication state
    state.isAuthenticated = await client.isAuthenticated()
    state.user = await client.getUser()
    state.loading = false
    console.log('setupAuth end')
  }

  return {
    install: (app: App) => {
      app.config.globalProperties.$auth = authPlugin
      app.provide('$auth', app.config.globalProperties.$auth)
      console.log('auth install')
    }
  }
}