<script setup lang="ts">
import {ref, inject, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { infoStore } from '../stores/index'
import { useToast } from "primevue/usetoast"
import moment from 'moment'
import CommonService from '@/service/CommonService'
import consts from '@/consts/CommonConsts'
import commonMessage from '@/consts/CommonMessage'

const router = useRouter()
// userInfo.updateCmpCd("株式会社jazz")
const commonService = ref(new CommonService())
let loginMsg = ""
const dtFormat = consts.dtFormat
const sysDate = moment().format(dtFormat)
const toast:any = useToast()
let auth = inject<any>('$auth')
onMounted(() => {
  
  const isAuthenticated = auth.isAuthenticated.value
  if(isAuthenticated == null) {
    auth = inject<any>('$auth')
  }
  localStorage.removeItem('xxx-system')

  if(auth.isAuthenticated.value) {
    toast.add(commonMessage.MSG_00001)
    let loginUserList = auth.user.value
    console.log(loginUserList)
    commonService.value.getUserInfo({system_execKbn:'1', system_loginUser:loginUserList}).then(data => {
      console.log(data);
      if(data.data.length == 0) {
        toast.removeAllGroups()
        toast.add(commonMessage.MSG_00002)
      } else {
        let userId = data.data[0].usr_id
        console.log(userId)
        let authUpdate = true
        const userInfo = infoStore()
        userInfo.updateCmpCd(data.data[0].cmd_cd)
        userInfo.updateJigCd(data.data[0].jig_cd)
        userInfo.updateUserNm(data.data[0].user_nm)
        toast.removeAllGroups()
        router.push({name:'menu'})
      }
    })
  } else {
    auth.loginWithRedirect()
  }
})

// const Logout =() => {
//   auth.logout({returnTo:window.location.origin,federated:true})
// }


</script>

background:rgb(160,185,224)
