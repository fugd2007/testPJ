import { ref, computed } from 'vue'
import { defineStore } from 'pinia'
import moment from 'moment'

// export const useCounterStore = defineStore('counter', () => {
//   const count = ref(0)
//   const doubleCount = computed(() => count.value * 2)
//   function increment() {
//     count.value++
//   }

//   return { count, doubleCount, increment }
// })
export interface GlobalState {
  userInfo:Record<string, unknown>
}
export const infoStore = defineStore({
  id: 'userInfo',
  state: () => ({
    cmd_cd: '株式会社JET',
    jig_cd: 'P01xx',
    jig_nm: '東京工場',
    user_id: 'fugd2007@yahoo.co.jp',
    user_nm: '太郎',
    auth_update:true,
    jig_flg:true,
    last_date:moment().format('YYYY/MM/DD')
  }),
  getters: {
    // double: (state) => {
    //   return state.count * 2
    // }
  },
  actions: {
    updateCmpCd(cmd_cd) {
      this.cmd_cd = cmd_cd;
    },
    updateJigCd(jig_cd) {
      this.jig_cd = jig_cd;
    },
    updateJigNm(jig_nm) {
      this.jig_nm = jig_nm;
    },
    updateUserId(user_id) {
      this.user_id = user_id;
    },
    updateUserNm(user_nm) {
      this.user_nm = user_nm;
    },
    updateJigFlg(jig_flg) {
      this.jig_flg = jig_flg;
    }
  },
})
