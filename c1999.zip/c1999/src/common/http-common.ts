import axios from 'axios'
import router from '@/router'
import qs from 'qs'
import moment from 'moment'
import consts from '@/consts/CommonConsts'

const api = axios.create({
    baseURL:import.meta.env.BASE_URL,
    headers:{
        Accept:'application/json',
        'Content-Type':'application/json'
    },
    paramsSerializer:params => {
        return qs.stringify(params,{arrayFormat:'repeat'});
    }
});

api.interceptors.request.use(req =>{
    const dtFormat = consts.dtFormat;
    const sysDate = moment().format(dtFormat);
    if(!window.navigator.onLine) {
        throw new axios.Cancel(consts.network_offline);
    }
    return req;
});

api.interceptors.response.use(
    function (response) {
        return response;
    },
    function (error) {
        if (error.message == consts.network_offline) {
            return Promise.reject(error);
        } else {
            error.config.data = '';
            if (error.message == 'Network Error') {
                let errorApiName = '';
                if (error.config.url == 'pulldown') {
                    errorApiName = 'pulldown'
                } else {
                    // TODO 
                    // if (error.config.params.system_execKbn == consts.execKbn_init) {
                    //     // 初期化
                    //     errorApiName = 'actionlog';
                    // } else if (error.config.params.system_execKbn == consts.execKbn_search) {
                    //     // 検索
                    //     errorApiName = 'getDataSelect';
                    // }
                }
                const errorTimestamp = moment().format('YYYY-MM-DD HH:mm:ss')
                router.push({name:'systemError', params:{
                    errorApiName:errorApiName,
                    errorUrl: error.config.baseURL + error.config.url,
                    errorParam: JSON.stringify(error.config.params),
                    errorTimestamp: errorTimestamp,
                    errorMsg:'タイムアウトエラー',
                    errorStackTrace: JSON.stringify(error)
                }})
                return Promise.reject(error);
            }
        }
    }
);
export default api;
