import api from '@/common/http-common'

export default class ProductService {

    getProductsMini(condParams) {
        return api.get('demo/data/product.json', {params:condParams}).then(res => res.data);
    }
}