export default {
    name : 'common-consts',
    dtFormat : 'YYYY/MM/DD',
    network_offline: 'offLine',
    transactionscreenCount: 2,
    lifeTime: 6000,
    maxFileSize:51200000,
    calOptionos :
    {
        format:'YYYY/MM/DD',
        placeholder:'',
        readonly:false,
        // Translations can be done here
        months:['１月','２月','３月','４月','５月','６月','７月','８月','９月','１０月','１１月','１２月'],
        weekdays:['日','月','火','水','木','金','土'],
        weekdays_short:['日','月','火','水','木','金','土'],
        updateButton:false
    },
    
}