import consts from '@/consts/CommonConsts'

export default {
    name : 'common-message',
    MSG_00001 : {severity:'error', summary:'取得中', detail:'ユーザ情報取得中',group:'br', life:consts.lifeTime},
    MSG_00002 : {severity:'error', summary:'取得中', detail:'ユーザ情報が取得できない為利用出来ません。',group:'br', life:consts.lifeTime},
    MSG_000066 : {severity:'error', summary:'情報', detail:'ネットワークの問題を検知したため、処理中断しました。',group:'br', life:consts.lifeTime},
    MSG_00003 : {severity:'error', summary:'更新', detail:'入力不正です。',group:'br', life:consts.lifeTime},
    MSG_00004 : {severity:'error', summary:'更新', detail:'更新しました。',group:'br', life:consts.lifeTime},
    MSG_00005 : {severity:'error', summary:'更新', detail:'他のユーザが更新した可能性があります。一部データの更新失敗しました。',group:'br', life:consts.lifeTime},
    MSG_00006 : {severity:'error', summary:'検索', detail:'[ItemNm]が不正です。',group:'br', life:consts.lifeTime},
    MSG_00007 : {severity:'error', summary:'検索', detail:'[PageNum]:page\n[ItemNm]を入力してください。',group:'br', life:consts.lifeTime},
}