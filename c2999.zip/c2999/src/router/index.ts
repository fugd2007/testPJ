import { createRouter, createWebHashHistory } from 'vue-router'

const routes = [
    // {
    //   path: '/',
    //   name: 'home',
    //   component: HomeView,
    //   meta: {title:'home'}
    // },
    {
      path: '/',
      name: 'login',
      component: () => import('../views/Login.vue'),
      meta: {title:'ログイン'}
    },
    {
      path: '/callback',
      name: 'callback',
      component: () => import('../views/CallBack.vue'),
      meta: {title:'ログイン'}
    },
    // {
    //   path: '/menu',
    //   name: 'menu',
    //   component: () => import('../views/Menu.vue'),
    //   meta: {title:'メニュー'}
    // },    
    {
      path: '/about',
      name: 'about',
      component: () => import('../views/AboutView.vue'),
      meta: {title:'説明'}
    },
    // vue-router 4.1.4 (2022-08-22) 対応
    {
      path: '/systemError/:errorApiName/:errorUrl/:errorParam/:errorTimestamp/:errorMsg/:errorStackTrace',
      name: 'systemError',
      component: () => import('../components/SystemError.vue'),
      meta: {title:'システムエラー'},
      props: true
    }
  ];
  const router = createRouter({
  //  history: createWebHashHistory(import.meta.env.BASE_URL),
    history: createWebHashHistory(),
    routes,
  });
  router.beforeEach((to,from,next) => {
    const DEFAULT_TITLE = ' - xxxx system'
    const nearestWithTitle = to.matched.slice().reverse().find(r => r.meta && r.meta.title);

    if (nearestWithTitle) {
      document.title = `${nearestWithTitle.meta.title}`;
      document.title += `${DEFAULT_TITLE}`;
    }
    next();
  })
  export default router

