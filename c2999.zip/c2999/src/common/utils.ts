/**
 * utils.ts 共通jsファイル
 */
import {ref} from 'vue'
import { useRouter } from 'vue-router'
import api from '@/common/http-common'
import CommonMessage from '@/consts/CommonMessage'
import consts from '@/consts/CommonConsts' 
import { infoStore } from '@/stores/index'

export default () => {
  const router = useRouter()
  // 日付有効性チェック
  const date_regex_f = /^(19\d{2}|20\d{2}|21[0]{2})\/(0[1-9]|1[0-2])\/(0[1-9]|1\d|2\d|3[01])$/
  const date_regex_8 = /^(19\d{2}|20\d{2}|21[0]{2})(0[1-9]|1[0-2])(0[1-9]|1\d|2\d|3[01])$/
  const date_regex_4 = /^(0[1-9]|1[0-2])(0[1-9]|1\d|2\d|3[01])$/
  // 年月有効性チェック
  const date_regex_ym_f = /^(19\d{2}|20\d{2}|21[0]{2})\/(0[1-9]|1[0-2])$/
  const date_regex_ym_6 = /^(19\d{2}|20\d{2}|21[0]{2})(0[1-9]|1[0-2])$/
  const date_regex_ym_2 = /^(0[1-9]|1[0-2])$/
  // 年有効性チェック
  const date_regex_year_f = /^(19\d{2}|20\d{2}|21[0]{2})$/

  // 年月有効性チェック YYYYMMDD
  const isValidate = (dt) => {
    if (dt == null || dt=='') {
      return true
    }
    if((dt.length == 10 && date_regex_f.test(dt)) || (dt.length == 8 && date_regex_8.test(dt)) || (dt.length == 4 && date_regex_4.test(dt))) {
      return true
    } else if (dt instanceof Date) {
      return true
    }
    return false
  }
  // 年月有効性チェック YYYYMM
  const isValidateYearMon = (dt) => {
    if (dt == null || dt=='') {
      return true
    }
    if((dt.length == 7 && date_regex_ym_f.test(dt)) || (dt.length == 6 && date_regex_ym_6.test(dt)) || (dt.length == 4 && date_regex_ym_2.test(dt))) {
      return true
    } else if((dt.length == 10 && date_regex_f.test(dt)) || (dt.length == 8 && date_regex_8.test(dt))) {
      return true
    } else if (dt instanceof Date) {
      return true
    }
    return false
  }
  // 年有効性チェック YYYY
  const isValidateYear = (dt) => {
    if (dt == null || dt=='') {
      return true
    }
    if((dt.length == 4 && date_regex_year_f.test(dt))) {
      return true
    }
    return false
  }

  // エラー画面処理
  const resultError =(data)=>{
    return router.push({name:'systemError',
      params:{
        errorApiName: data.info[0].errorApiName,
        errorUrl: data.info[0].errorUrl,
        errorParam: JSON.stringify(data.info[0].errorParam),
        errorTimestamp: data.info[0].errorTimestamp,
        errorMsg: data.info[0].errorMsg,
        errorStackTrace: data.info[0].errorStackTrace
    }})
  }

  // エラー色クリア
  const clearError = () => {
    const el:any = document.getElementById('data_table')
    const content = el.querySelectorAll(':scope > tr, :scope > div > table > tbody > tr');
    for (let j = 0; j < content.length; j++) {
      for (let i = 0; i < content[j].children.length; i++) {
          // Get style
          let cellStyle = content[j].children[i].getAttribute('style');
          if (cellStyle) {
            cellStyle = cellStyle.replaceAll(/border-color: red;/g, '')
            content[j].children[i].setAttribute('style', cellStyle);
          }
      }
    }
  }
  const userInfo = infoStore()
  return {isValidate, isValidateYearMon, isValidateYear,resultError, clearError, userInfo}
}