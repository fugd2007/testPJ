<template>
  <div id="app-div" class="body-box">
    <ConfirmDialog/>
    <Toast position="top-right" group="br"/>
    <router-view />
  </div>
</template>