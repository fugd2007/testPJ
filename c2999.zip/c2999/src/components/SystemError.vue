<script setup lang="ts">
import { onMounted } from 'vue';

defineProps({
  errorApiName: String,
  errorUrl: String,
  errorParam: String,
  errorTimestamp: String,
  errorMsg: String,
  errorStackTrace: String
})

onMounted(() => {
  removedBlock()
})
const removedBlock = ()=> {
  const elems:Array<HTMLElement> = Array.from(document.querySelectorAll('.p-blockui,.p-blockiu-document,.p-component-overlay'));
  for (const elem of elems) {
    elem.classList.remove('.p-blockui,.p-blockiu-document,.p-component-overlay')
  }
}
</script>


<template>
  <div>
    <strong>システムエラーが発生しました</strong>
    <div class="row">
      <label for="errorTimestamp" class="col-2">発生日：</label>
      <div class="col-10">
        <span>{{ errorTimestamp }}</span>
      </div>
    </div>
    <div class="row">
      <label for="errorMsg" class="col-2">実行API：</label>
      <div class="col-10">
        <span>{{ errorUrl }}</span>
      </div>
    </div>
    <div class="row">
      <label for="errorMsg" class="col-2">トリガー：</label>
      <div class="col-10">
        <span>{{ errorApiName }}</span>
      </div>
    </div>
    <div class="row">
      <label for="errorMsg" class="col-2">パラメータ：</label>
      <div class="col-10">
        <span>{{ errorParam }}</span>
      </div>
    </div>
    <div class="row">
      <label for="errorMsg" class="col-2">メッセージ：</label>
      <div class="col-10">
        <span>{{ errorMsg }}</span>
      </div>
    </div>
    <div class="row">
      <label for="errorMsg" class="col-2">詳細情報：</label>
      <div class="col-10">
        <span>{{ errorStackTrace }}</span>
      </div>
    </div>
  </div>

</template>

<style>
.break-word {
  word-wrap: break-word;
}
</style>

