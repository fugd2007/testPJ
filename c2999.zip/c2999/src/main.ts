import './assets/main.css'
import './assets/styles/styles.css'
// import 'bootstrap/dist/css/bootstrap.min.css'
// import 'primevue/resources/themes/saga-blue/theme.css'
// import 'primevue/resources/primevue.min.css'
// import 'primeicons/primeicons.css'

// import (import.meta.env.VITE_APP_CSS_ENV)
import.meta.env.VITE_APP_CSS_ENV

import { createApp, reactive } from 'vue'
import { createPinia } from 'pinia'

import App from './App.vue'
import router from './router'
import {infoStore} from './stores'
import PrimeVue from 'primevue/config'
import consts from '@/consts/CommonConsts'
import moment from 'moment'

import ToastService from 'primevue/toastservice'
import Confirmationservice from 'primevue/confirmationservice'

import Calendar from 'primevue/calendar'
import DataTable from 'primevue/datatable'
import Column from 'primevue/column'
import Dropdown from 'primevue/dropdown'
import InputText from 'primevue/inputtext'
import Button from 'primevue/button'
import FileUpload from 'primevue/fileupload'
import Dialog from 'primevue/dialog'
import InputNumber from 'primevue/inputnumber'
import InputMask from 'primevue/inputmask'
import Toolbar from 'primevue/toolbar'
import RadioButton from 'primevue/radiobutton'
import Textarea from 'primevue/textarea'
import Paginator from 'primevue/paginator'
import Toast from 'primevue/toast'
import Checkbox from 'primevue/checkbox'
import Message from 'primevue/message'
import Menu from 'primevue/menu'
import ToggleButton from 'primevue/togglebutton'
import MultiSelect from 'primevue/multiselect'
import InlineMessage from 'primevue/inlinemessage'
import TabView from 'primevue/tabview'
import TabPanel from 'primevue/tabpanel'
import ConfirmDialog from 'primevue/confirmdialog'
import ColumnGroup from 'primevue/columngroup'
import BlockUI from 'primevue/blockui'
import Row from 'primevue/row'
import CascadeSelect from 'primevue/cascadeselect'
import AutoComplete from 'primevue/autocomplete'
import ScrollPanel from 'primevue/scrollpanel'
import Tooltip from 'primevue/tooltip'
import {setupAuth} from './auth'
// import MenuBar from '@/components/MenuBar.vue'

const app = createApp(App)

app.use(createPinia())
app.use(router)
app.use(PrimeVue, {
    zIndex: {
        modal: 1100,        //dialog, sidebar
        overlay: 1000,      //dropdown, overlaypanel
        menu: 1000,         //overlay menus
        tooltip: 1100       //tooltip
    },
    locale: {
        accept: 'OK',
        reject: 'キャンセル',
        choose: '参照',
        upload: 'Upload',
        cancel: 'Cancel',
        dayNamesMin: ['日','月','火','水','木','金','土'],
        monthNames: ['１月','２月','３月','４月','５月','６月','７月','８月','９月','１０月','１１月','１２月'],
        monthNamesShort: ['１月','２月','３月','４月','５月','６月','７月','８月','９月','１０月','１１月','１２月'],
        firstDayOfWeek:0,
        dateFormat:'yyyy/mm/dd',  //dummy
        today: 'Today',
        clear: 'Clear',
        //...
    }
})

function callbackRedirect(appState:any) {
    router.push(
        appState && appState.targetUrl ? appState.targetUrl : '/'
    )
}

router.beforeEach(function (to, from, next) {
    const dtFormat = consts.dtFormat
    const sysDate = moment().format(dtFormat)
    window.scrollTo(0,0)
    // Auth0 セットアップ
    // setupAuth(callbackRedirect).then((auth) => {
    //     app.use(auth);
    //     const userInfo = infoStore();
    //     if (!(to.name == 'login' || to.name == 'callback') && (userInfo.last_date != sysDate)) {
    //         localStorage.removeItem('xxx-system');
    //         next({name:'login'});
    //     } else {
    //         if (!(to.name == 'login' || to.name == 'callback') && (!userInfo.user_id || (String)(userInfo.user_id).trim() == '')) {
    //             next({name:'login'});
    //         } else {
    //             next();
    //         }
    //     }
    // })
     next();

})

app.use(ToastService)
app.use(Confirmationservice)
app.config.globalProperties.$appState = reactive({darkTheme:false,codeSandbox:true,sourceType:'options-api'});
app.component('Calendar',Calendar);
app.component('DataTable',DataTable);
app.component('Column',Column);
app.component('Dropdown',Dropdown);
app.component('InputText',InputText);
app.component('Button',Button);
app.component('FileUpload',FileUpload);
app.component('Dialog',Dialog);
app.component('InputNumber',InputNumber);
app.component('InputMask',InputMask);
app.component('Toolbar',Toolbar);
app.component('RadioButton',RadioButton);
app.component('Textarea',Textarea);
app.component('Paginator',Paginator);
app.component('Toast',Toast);
app.component('Checkbox',Checkbox);
app.component('Message',Message);
app.component('Menu',Menu);
app.component('ToggleButton',ToggleButton);
app.component('MultiSelect',MultiSelect);
app.component('InlineMessage',InlineMessage);
app.component('TabView',TabView);
app.component('TabPanel',TabPanel);
app.component('ConfirmDialog',ConfirmDialog);
app.component('ColumnGroup',ColumnGroup);
app.component('BlockUI',BlockUI);
app.component('Row',Row);
app.component('CascadeSelect',CascadeSelect);
app.component('AutoComplete',AutoComplete);
app.component('ScrollPanel',ScrollPanel);
// app.component('MenuBar',MenuBar);
app.directive('tooltip',Tooltip);

router.isReady().then(() => {
    app.mount('#app')
});

