<template>
  <div class="row menu-bar">
    <menu-bar screenId="AboutView"/>
  </div>
  <div class="about">
    <h1>This is an about page</h1>
  </div>
</template>
<script setup lang="ts">
import { infoStore } from '@/stores/index'

  
const myStore = infoStore()
//  alert(import.meta.env.MODE)

myStore.updateCmpCd("株式会社jazz");
console.log('myStore.cmd_cd' + myStore.cmd_cd);


</script>

<style>
@media (min-width: 1024px) {
  .about {
    min-height: 20vh;
    display: flex;
    align-items: center;
  }
}
</style>
