import api from '@/common/http-common'

export default class CommonService {
    // getUserInfo(condParams) {
    //     return api.get('common/login', {params:condParams}).then(res => res.data);
    // }
    getUserInfo(condParams) {
        return api.get('demo/data/userInfo.json', {params:condParams}).then(res => res.data);
    }
    // getPulldown(condParams) {
    //     return api.get('pulldown', {params:condParams}).then(res => res.data);
    // }
    getInfoSelectDialog(condParams) {
        // return api.get('notice', {params:condParams}).then(res => res.data);
        return api.get('demo/data/notice.json', {params:condParams}).then(res => res.data);
    }
    updateInfoSelect(data:JSON, condParams) {
        // return api.post('notice', data, {params:condParams}).then(res => res.data);
        return api.post('demo/data/notice.json', data, {params:condParams}).then(res => res.data);
    }
    actionlog(condParams) {
        // return api.get('common/actionlog', {params:condParams}).then(res => res.data);
        return api.get('demo/data/actionlog.json', {params:condParams}).then(res => res.data);
    }
}